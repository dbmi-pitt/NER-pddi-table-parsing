

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

import Main.KeyValue;

public class DataBaseAnnotationSaver {
	public Connection conn = null;
	public Statement stmt = null;
	public ResultSet rs = null;
	
	public DataBaseAnnotationSaver(){
		 try {
			 BufferedReader br = new BufferedReader(new FileReader(
						"settings.cfg"));
				// StringBuilder sb = new StringBuilder();
				String line = br.readLine();
				String host="";
				String database_name= "";
				String database_username = "";
				String database_password = "";
				String database_port = "";
				while (line != null) {
					KeyValue kv = new KeyValue();
					String[] parts = line.split(";");
					kv.key = parts[0];
					kv.value = parts[1];
					if (kv.key.equals("database_host")) {
						host = kv.value;
					}
					if (kv.key.equals("database_name")) {
						database_name = kv.value;
					}
					if (kv.key.equals("database_username")) {
						database_username = kv.value;
					}
					if (kv.key.equals("database_password")) {
						database_password = kv.value;
					}
					if (kv.key.equals("database_port")) {
						database_port = kv.value;
					}
					line = br.readLine();
				}
			 	
				database_password = database_password.replace("\"", "");
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				String connectionUrl = "jdbc:mysql://"+host+":"+database_port+"/"+database_name;
				String connectionUser = database_username;
				String connectionPassword = database_password;
				conn = DriverManager.getConnection(connectionUrl, connectionUser, connectionPassword);	
		 }catch(SQLException ex)
		 {
			 ex.printStackTrace();
			 System.out.println("SQLException: " + ex.getMessage());
			    System.out.println("SQLState: " + ex.getSQLState());
			    System.out.println("VendorError: " + ex.getErrorCode());
		 }
		 catch(Exception ex)
		 {
			 ex.printStackTrace();
		 }
	}
	
//	public void SaveArticleAnnotationToDB(Article art)
//	{
//			
//	    	  		LinkedList<Annotation> annot = cells[j][k].annotations;
//	    	  		for(int l = 0; l<annot.size();l++)
//	    	  		{
//	    	  			Statement stmt8 = conn.createStatement();
//	        	  		String insertTableSQL8 = "INSERT INTO Annotation (Content,Start,End,AnnotationID,AgentType,AgentName,AnnotationURL,EnvironmentDescription,Cell_idCell,AnnotationDescription,AnnotationSchemaVersion,DateOfAction, Location) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
//	        	  		PreparedStatement preparedStatement8 = conn.prepareStatement(insertTableSQL8,Statement.RETURN_GENERATED_KEYS);
//	        	  		preparedStatement8.setString(1,annot.get(l).getContent());
//	        	  		preparedStatement8.setInt(2,annot.get(l).getStart());
//	        	  		preparedStatement8.setInt(3,annot.get(l).getEnd());
//	        	  		preparedStatement8.setString(4,annot.get(l).getID());
//	        	  		preparedStatement8.setString(5,"Software");
//	        	  		preparedStatement8.setString(6,annot.get(l).getSource());
//	        	  		preparedStatement8.setString(7,annot.get(l).getURL());
//	        	  		preparedStatement8.setString(8,annot.get(l).getEnvironment()); 
//	        	  		preparedStatement8.setInt(9,CellId);
//	        	  		preparedStatement8.setString(10,annot.get(l).getDescription());
//	        	  		preparedStatement8.setString(11,annot.get(l).getAgentVersion());// Should be version
//	        	  		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
//	        	  		Date date = new Date();
//	        	  		preparedStatement8.setString(12,dateFormat.format(date));
//	        	  		preparedStatement8.setString(13,annot.get(l).getLocation()); // Should be location
//	        	  		// execute insert SQL stetement
//	        	  		preparedStatement8.executeUpdate();
//	    	  		}
//	               
//	            
//	}
	
	public void CloseDBConnection()
	{
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
