import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

import Main.MarvinSemAnnotator;
import Main.Word;
import Main.WordMeaningOutputElement;


public class MetaMapAnnotatorMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataBaseAnnotationSaver dbas = new DataBaseAnnotationSaver();
		try {
			Statement stmt = dbas.conn.createStatement();
			String insertTableSQL = "SELECT * FROM Cell where idCell>1035590";
			ResultSet rs = stmt.executeQuery(insertTableSQL);
			MarvinSemAnnotator marvin = new MarvinSemAnnotator();
			while (rs.next()) {
				int idCell = rs.getInt("idCell");
				String CellID = rs.getString("CellID");
				String CellType = rs.getString("CellType");
				int Table_idTable  = rs.getInt("Table_idTable");
				int RowN = rs.getInt("RowN");
				int ColumnN = rs.getInt("ColumnN");
				String Content = rs.getString("Content");
				System.out.println( Content);
				if(Content==null)
				{
					Content = "";
				}
				int mathTypeIndex = Content.indexOf("MathType@");
				if(mathTypeIndex>0)
				{
					Content = Content.substring(0, mathTypeIndex);
				}
				LinkedList<Word> words = null;
				if(Content!=null){
					//System.out.println(valueToParse);
					Content = Content.trim();
					words = marvin.annotate(Content);
					for(Word w:words)
					{
						
						for(WordMeaningOutputElement wm: w.wordmeanings)
						{
							System.out.println(wm.AgentName);
							Statement stmt8 = dbas.conn.createStatement();
		        	  		String insertTableSQL8 = "INSERT INTO Annotation (Content,Start,End,AnnotationID,AgentType,AgentName,AnnotationURL,EnvironmentDescription,Cell_idCell,AnnotationDescription,AnnotationSchemaVersion,DateOfAction, Location) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
		        	  		PreparedStatement preparedStatement8 = dbas.conn.prepareStatement(insertTableSQL8,Statement.RETURN_GENERATED_KEYS);
		        	  		preparedStatement8.setString(1,wm.appearingWord);
		        	  		preparedStatement8.setInt(2,wm.startAt);
		        	  		preparedStatement8.setInt(3,wm.endAt);
		        	  		preparedStatement8.setString(4,wm.id);
		        	  		preparedStatement8.setString(5,"Software");
		        	  		preparedStatement8.setString(6,wm.AgentName);
		        	  		preparedStatement8.setString(7,wm.URL);
		        	  		preparedStatement8.setString(8,wm.EnvironmentDesc); 
		        	  		preparedStatement8.setInt(9,idCell);
		        	  		preparedStatement8.setString(10,wm.Description);
		        	  		preparedStatement8.setString(11,wm.AgentVersion);// Should be version
		        	  		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		        	  		Date date = new Date();
		        	  		preparedStatement8.setString(12,dateFormat.format(date));
		        	  		preparedStatement8.setString(13,wm.Location); // Should be location
		        	  		// execute insert SQL stetement
		        	  		preparedStatement8.executeUpdate();
						}
					}
				} 
			  }
			
			dbas.CloseDBConnection();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
